package web

import "embed"

//go:embed "templates" "static"
var Files embed.FS
